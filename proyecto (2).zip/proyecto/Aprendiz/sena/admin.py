from django.contrib import admin
from .models import Aprendiz, Programa, instructores, Competencias
# Register your models here.

admin.site.register(Aprendiz)
admin.site.register(Programa)
admin.site.register(instructores)
admin.site.register(Competencias)