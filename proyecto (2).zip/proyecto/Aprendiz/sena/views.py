
from django.shortcuts import render, redirect, get_object_or_404
from .models import Aprendiz
from .forms import AprendizForm


# Página principal
def inicio(request):
    return render(request, 'sena/index.html')


# Registrar un aprendiz
def registrar_aprendiz(request):
    if request.method == 'POST':
        formulario = AprendizForm(request.POST)

        if formulario.is_valid():
            formulario.save()
            return redirect('registros_aprendices')
    else:
        formulario = AprendizForm()

    return render(
        request,
        'sena/registrar.html',
        {'formulario': formulario}
    )


# Mostrar los aprendices registrados
def registros_aprendices(request):
    aprendices = Aprendiz.objects.all().order_by('apellido', 'nombre')

    return render(
        request,
        'sena/registros.html',
        {'aprendices': aprendices}
    )



# Editar un aprendiz
def editar_aprendiz(request, pk):
    print("¡ENTRÓ A EDITAR_APRENDIZ!", pk)

    aprendiz = get_object_or_404(Aprendiz, pk=pk)

    if request.method == 'POST':
        formulario = AprendizForm(
            request.POST,
            instance=aprendiz
        )

        if formulario.is_valid():
            formulario.save()
            return redirect('registros_aprendices')
    else:
        formulario = AprendizForm(instance=aprendiz)

    return render(
        request,
        'sena/editar.html',
        {
            'formulario': formulario,
            'aprendiz': aprendiz
        }
    )


# Eliminar un aprendiz por documento
def eliminar_aprendiz(request, documento):
    aprendiz = get_object_or_404(
        Aprendiz,
        documento=documento
    )

    if request.method == 'POST':
        aprendiz.delete()
        return redirect('registros_aprendices')

    return render(
        request,
        'sena/eliminar.html',
        {'aprendiz': aprendiz}
    )


    
