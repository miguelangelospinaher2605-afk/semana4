
from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),

    path(
        'registrar/',
        views.registrar_aprendiz,
        name='registrar_aprendiz'
    ),

    path(
        'aprendices/',
        views.registros_aprendices,
        name='registros_aprendices'
    ),

    path(
        'editar/<int:pk>/',
        views.editar_aprendiz,
        name='editar_aprendiz'
    ),

    path(
        'eliminar/<str:documento>/',
        views.eliminar_aprendiz,
        name='eliminar_aprendiz'
    ),
]
