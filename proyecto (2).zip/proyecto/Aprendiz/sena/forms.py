
from django import forms
from .models import Aprendiz


class AprendizForm(forms.ModelForm):
    class Meta:
        model = Aprendiz
        fields = [
            'nombre',
            'apellido',
            'documento',
            'correo',
            'telefono',
            'ficha',
            'programa',
        ]

        widgets = {
            'nombre': forms.TextInput(attrs={
                'placeholder': 'Ingrese los nombres'
            }),
            'apellido': forms.TextInput(attrs={
                'placeholder': 'Ingrese los apellidos'
            }),
            'documento': forms.NumberInput(attrs={
                'placeholder': 'Número de documento'
            }),
            'correo': forms.EmailInput(attrs={
                'placeholder': 'correo@ejemplo.com'
            }),
            'telefono': forms.NumberInput(attrs={
                'placeholder': 'Número de teléfono'
            }),
            'ficha': forms.NumberInput(attrs={
                'placeholder': 'Número de ficha'
            }),
            'programa': forms.TextInput(attrs={
                'placeholder': 'Nombre del programa'
            }),
        }
