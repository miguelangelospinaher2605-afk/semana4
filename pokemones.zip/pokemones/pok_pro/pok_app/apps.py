from django.apps import AppConfig


class PokAppConfig(AppConfig):
    name = 'pok_app'
