
from django.urls import path
from . import views

urlpatterns = [
    path(
        'registrar-pokemon/',
        views.registrar_pokemon,
        name='registrar_pokemon'
    ),
]
