

from django.contrib import admin
from .models import Pokemon, Gimnasio, Entrenador


@admin.register(Pokemon)
class PokemonAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'peso', 'naturaleza', 'entrenado')
    search_fields = ('nombre', 'naturaleza')
    list_filter = ('entrenado', 'naturaleza')


@admin.register(Gimnasio)
class GimnasioAdmin(admin.ModelAdmin):
    list_display = ('lider_gym', 'naturaleza', 'medallas')
    search_fields = ('lider_gym', 'naturaleza')


@admin.register(Entrenador)
class EntrenadorAdmin(admin.ModelAdmin):
    list_display = ('id_documento', 'nombre', 'apellido', 'medallas')
    search_fields = ('id_documento', 'nombre', 'apellido')
    list_filter = ('medallas',)
    filter_horizontal = ('pokemones',)

