
from django.shortcuts import render, redirect
from .forms import PokemonForm

def inicio(request):
    return render(request, 'pok_app/index.html')

def registrar_pokemon(request):
    if request.method == 'POST':
        formulario = PokemonForm(request.POST)

        if formulario.is_valid():
            formulario.save()
            return redirect('registrar_pokemon')
    else:
        formulario = PokemonForm()

    return render(
        request,
        'pok_app/registrar_pokemon.html',
        {'formulario': formulario}
    )

